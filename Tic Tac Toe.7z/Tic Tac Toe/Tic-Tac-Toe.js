const winningCombos = [
	[0,1,2],
	[3,4,5],
	[6,7,8],
	[0,3,6],
	[1,4,7],
	[2,5,8],
	[0,4,8],
	[2,4,6]
];

//helper function to return all the quadrants
const grid = () => Array.from(document.getElementsByClassName('q'));

//helper function to change id from q# to #(# -> number of quadrant)
const qNumId = (qEl) => Number.parseInt(qEl.id.replace('q',''));

//helper function to return array of all quadrants that dont have X/O in it
const emptyQs = () => grid().filter(_qEl => _qEl.innerText === '');

/* helper function to tell whether or not all items in array of 3 quadrants are same or not 
i.e. if all are X/O win; but don't count empty spaces without X/O */
const allSame = (arr) => arr.every(_qEl => _qEl.innerText === arr[0].innerText && _qEl.innerText !== '');

//function takes index of quadrant and the letter oon it(X/O)
const takeTurn = (index, letter) => grid()[index].innerText = letter;

//function reurns a random quadrant thats empty
const opponentChoice = (userSelection) => qNumId(emptyQs()[Math.floor(Math.random() * emptyQs().length)]);

//function that runs wwhen we end the game i.e. all quadrants are filled
const endGame = (winningSequence) => {
	winningSequence.forEach(_qEl => _qEl.classList.add('winner'));
	disableListeners;
};

//function to check who wins
const checkForVictory = () => {
	let victory = false;
	winningCombos.forEach(_c => {
		const _grid = grid();
		const sequence = [_grid[_c[0]], _grid[_c[1]], _grid[_c[2]]];
		if(allSame(sequence)) {
			victory = true;	
			endGame(sequence);
		}
	});
	return victory;
};

//function for every opponent turn, will pick a quadrant on its own
const opponentTurn = (userSelection) => {
	disableListeners();
	setTimeout(() => {
		takeTurn(opponentChoice(userSelection), 'o');
		//console.log(emptyQs());
		if(!checkForVictory())
			enableListeners();
	}, 1000);
};

//function to check which quadrant we click on or AI clicks on
const clickFn = ($event) => {
	takeTurn(qNumId($event.target), 'x'); //we are X and opponent is O
	if(!checkForVictory())
		opponentTurn(qNumId($event.target));
};

//function to listen for user's turn
const enableListeners = () => grid().forEach(_qEl => addEventListener('click', clickFn));

//function to disable listener when AI's turn
const disableListeners = () => grid().forEach(_qEl => removeEventListener('click', clickFn));

enableListeners();